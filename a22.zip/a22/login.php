<!-- login.php -->

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="style.css" />
  <script src="https://kit.fontawesome.com/9964e735a4.js" crossorigin="anonymous"></script>
  <title>Vehicle Home</title>
</head>

<body>
  <div id="header">
    <div class="container">
      <nav>
        <img src="images/logo2.png" alt="logo" class="logo" />
        <ul id="sidemenu">
          <li><a href="home.php">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="register.php">Register</a></li>
          <li><a href="login.php">Login</a></li>
          <li><a href="search.php">Search</a></li>
          <i class="fas fa-times" onclick="closemenu()"></i>
        </ul>
        <i class="fas fa-bars" onclick="openmenu()"></i>
      </nav>
    </div>
  </div>

  <!-- Login Form -->
  <div class="login-container">
    <?php
    // Include the PHP file that contains the database connection
    include('database.php');

    // Start the session
    session_start();

    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      // Fetch values from the form
      $loginUsername = $_POST['loginUsername'];
      $loginPassword = $_POST['loginPassword'];

      // Check if the user is registered
      $query = "SELECT * FROM users WHERE username='$loginUsername'";
      $result = mysqli_query($conn, $query);

      if (mysqli_num_rows($result) > 0) {
        // User is registered, check the password
        $row = mysqli_fetch_assoc($result);
        $hashedPassword = $row['password'];

        if (password_verify($loginPassword, $hashedPassword)) {
          // Password is correct, set a session variable to indicate login
          $_SESSION['loggedin'] = true;

          // Redirect to the Add Car form
          header("Location: add_car.php");
          exit;
        } else {
          // Password is incorrect, display a message
          echo '<p>Password is incorrect. Please try again.</p>';
        }
      } else {
        // User is not registered, display a message
        echo '<p>User not registered. Please register first.</p>';
      }
    }
    ?>
    <form id="loginForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <h2>Login</h2>
      <label for="loginUsername">Username:</label>
      <input type="text" id="loginUsername" name="loginUsername" required />

      <label for="loginPassword">Password:</label>
      <input type="password" id="loginPassword" name="loginPassword" required />

      <div class="error-message" id="login-error-message"></div>

      <button type="submit">Login</button>
    </form>
  </div>

  <!-- ... (your existing HTML code) ... -->

  <script>
    var side = document.getElementById("sidemenu");

    function openmenu() {
      side.style.right = "0";
    }

    function closemenu() {
      side.style.right = "-200px";
    }
  </script>

  <script>
    document.addEventListener("DOMContentLoaded", function() {
      // Get all form inputs and buttons
      var formInputs = document.querySelectorAll("form input");
      var buttons = document.querySelectorAll("form button");

      // Add focus and blur event listeners to form inputs
      formInputs.forEach(function(input) {
        input.addEventListener("focus", function() {
          this.style.backgroundColor = "yellow";
        });

        input.addEventListener("blur", function() {
          this.style.backgroundColor = "white";
        });
      });

      // Add mouseover event listener to buttons
      buttons.forEach(function(button) {
        button.addEventListener("mouseover", function() {
          this.style.backgroundColor = "lightblue";
        });

        button.addEventListener("mouseout", function() {
          this.style.backgroundColor = ""; // Reset to default background color
        });
      });
    });
  </script>
</body>

</html>