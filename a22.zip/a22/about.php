<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="style.css" />
  <script src="https://kit.fontawesome.com/9964e735a4.js" crossorigin="anonymous"></script>
  <title>Vehicle Home</title>
</head>

<body>
  <div id="header">
    <div class="container">
      <nav>
        <img src="images/logo2.png" alt="logo" class="logo" />
        <ul id="sidemenu">
          <li><a href="home.php">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="register.php">Register</a></li>
          <li><a href="login.php">Login</a></li>
          <li><a href="search.php">Search</a></li>
          <i class="fas fa-times" onclick="closemenu()"></i>
        </ul>
        <i class="fas fa-bars" onclick="openmenu()"></i>
      </nav>
    </div>
  </div>
  <?php
  // Include the PHP file that contains the database connection
  include('database.php');

  // Fetch data from the database 
  $query = "SELECT * FROM users";
  $result = mysqli_query($conn, $query);

  // Display fetched data
  // while ($row = mysqli_fetch_assoc($result)) {
  //   echo '<p>User ID: ' . $row['id'] . ', Username: ' . $row['user'] . '</p>';
  // }

  // Close the database connection
  mysqli_close($conn);
  ?>
  </div>

  <!-- about part start form here -->

  <div class="abouttext">
    <div class="main-text">
      <h3>What We Do</h3>
      <p>
        At Car Sale Hub, our mission is to provide a seamless and enjoyable
        experience for buying and selling vehicles. Explore a vast selection
        of high-quality cars, ranging from stylish sedans to robust SUVs and
        efficient hybrids. We connect buyers with trusted sellers, making the
        car shopping process convenient and reliable. Whether you're looking
        to upgrade your ride or sell your current vehicle, Car Sale Hub is
        your go-to destination for all your automotive needs. Join us in
        redefining the way cars are bought and sold!
      </p>
    </div>

    <div class="aboutimage">
      <img src="images/bg.png" alt="" height="500px" width="500px" />
    </div>
  </div>

  <h1 style="display: flex; justify-content: center; align-items: center">
    Our Staff
  </h1>
  <!-- Staff Section -->
  <div class="staff">
    <div class="staff-member">
      <img src="images/staff.jpeg" alt="Staff 1" class="staff-image" />
      <p>Bishworaj</p>
      <p>Austrila</p>
    </div>
  </div>

  <!-- Contact Us Section -->
  <div class="contact-part">
    <h1 style="
          display: flex;
          justify-content: center;
          align-items: center;
          margin-top: 30px;
        ">
      Contact Us
    </h1>

    <div class="contact-info">
      <p>Main Office:</p>
      <p>Sydeny</p>
    </div>

    <div class="contact-icons">
      <i class="fas fa-phone"></i>
      <p style="margin-bottom: 20px">+61-1234321567</p>

      <i class="fas fa-fax"></i>
      <p style="margin-bottom: 20px">+44 1-2222 8888</p>

      <i class="fas fa-envelope"></i>
      <p>vehiclehome@gmail.com</p>
    </div>
  </div>

  <!-- footer part -->
  <footer>
    <div class="container">
      <p>&copy; 2023 Vehicle Home. All rights reserved.</p>
    </div>
  </footer>

  <script>
    var side = document.getElementById("sidemenu");

    function openmenu() {
      side.style.right = "0";
    }

    function closemenu() {
      side.style.right = "-200px";
    }
  </script>
</body>

</html>