<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="style.css" />
    <script src="https://kit.fontawesome.com/9964e735a4.js" crossorigin="anonymous"></script>
    <title>Add Car</title>
</head>

<body>
    <div id="header">
        <div class="container">
            <nav>
                <img src="images/logo2.png" alt="logo" class="logo" />
                <ul id="sidemenu">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="register.php">Register</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="search.php">Search</a></li>
                    <i class="fas fa-times" onclick="closemenu()"></i>
                </ul>
                <i class="fas fa-bars" onclick="openmenu()"></i>
            </nav>
        </div>
    </div>

    <!-- Add Car Form -->
    <div class="login-container">
        <?php
        // Include the PHP file that contains the database connection
        include('database.php');

        // Check if the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Fetch values from the form
            $make = $_POST['make'];
            $model = $_POST['model'];
            $year = $_POST['year'];
            $mileage = $_POST['mileage'];
            $location = $_POST['location'];
            $price = $_POST['price'];

            // Check if an image is uploaded
            if (isset($_FILES['image'])) {
                $target_dir = 'uploads/';

                // Create the "uploads" directory if it doesn't exist
                if (!is_dir($target_dir)) {
                    mkdir($target_dir);
                }

                $target_file = $target_dir . basename($_FILES['image']['name']);
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

                // Check if the file is a valid image
                $validExtensions = array('jpg', 'jpeg', 'png', 'gif');
                if (in_array($imageFileType, $validExtensions)) {
                    // Move the uploaded file to the "uploads" directory
                    if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                        // File uploaded successfully, insert data into the database
                        $query = "INSERT INTO cars (make, model, year, mileage, location, price, image_path) VALUES ('$make', '$model', '$year', '$mileage', '$location', '$price', '$target_file')";
                        $result = mysqli_query($conn, $query);

                        if ($result) {
                            echo '<p>Car added successfully!</p>';
                        } else {
                            echo '<p>There was an error adding the car to the database.</p>';
                        }
                    } else {
                        echo '<p>Sorry, there was an error uploading your file.</p>';
                    }
                } else {
                    echo '<p>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</p>';
                }
            } else {
                echo '<p>No image uploaded.</p>';
            }
        }
        ?>

        <form id="addCarForm" method="post" enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <h2>Add Car</h2>
            <label for="make">Make:</label>
            <input type="text" id="make" name="make" required />

            <label for="model">Model:</label>
            <input type="text" id="model" name="model" required />

            <label for="year">Year:</label>
            <input type="text" id="year" name="year" required />

            <label for="mileage">Mileage:</label>
            <input type="text" id="mileage" name="mileage" required />

            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required />

            <label for="price">Price:</label>
            <input type="text" id="price" name="price" required />

            <label for="image">Car Image:</label>
            <input type="file" id="image" name="image" accept="image/*" required />

            <div class="error-message" id="addCar-error-message"></div>

            <button type="submit">Add Car</button>
        </form>
    </div>

    <script>
        var side = document.getElementById("sidemenu");

        function openmenu() {
            side.style.right = "0";
        }

        function closemenu() {
            side.style.right = "-200px";
        }
    </script>
</body>

</html>