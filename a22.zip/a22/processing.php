<?php

include('database.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $loginUsername = $_POST['loginUsername'];
    $loginPassword = $_POST['loginPassword'];

  

    if (empty($loginUsername) || empty($loginPassword)) {
        // You can send a JSON response indicating failure
        echo json_encode(['success' => false, 'message' => 'Both username and password are required']);
        exit();
    }
    $hashedPassword = password_hash($loginPassword, PASSWORD_DEFAULT);

    // Check if the user exists in the database and the password is correct
    $query = "SELECT id, username, password FROM users WHERE username = ? LIMIT 1";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $loginUsername);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $userId, $dbUsername, $dbPassword);

    if (mysqli_stmt_fetch($stmt)) {
        // Verify the password
        if (password_verify($loginPassword, $dbPassword)) {
            // Login successful
            session_start();
            $_SESSION['user_id'] = $userId;

            // You can send a JSON response indicating success
            echo json_encode(['success' => true]);
            exit();
        }
    }

    // Login failed
    // You can send a JSON response indicating failure
    echo json_encode(['success' => false, 'message' => 'Invalid username or password']);
    exit();
}
?>
