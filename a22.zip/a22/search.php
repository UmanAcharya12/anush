<?php
// Include the PHP file that contains the database connection
include('database.php');

// Initialize $result variable
$result = null;

// Check if a search query is submitted
if (isset($_GET['search'])) {
  $searchQuery = $_GET['search'];

  // Fetch data from the database based on the search query
  $query = "SELECT * FROM cars WHERE make LIKE '%$searchQuery%' OR model LIKE '%$searchQuery%'";
  $result = mysqli_query($conn, $query);
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="style.css" />
  <script src="https://kit.fontawesome.com/9964e735a4.js" crossorigin="anonymous"></script>
  <title>Vehicle Home</title>
</head>

<body>
  <div id="header">
    <div class="container">
      <nav>
        <img src="logo2.png" alt="logo" class="logo" />
        <ul id="sidemenu">
          <li><a href="home.php">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="register.php">Register</a></li>
          <li><a href="login.php">Login</a></li>
          <li><a href="search.php">Search</a></li>
          <i class="fas fa-times" onclick="closemenu()"></i>
        </ul>
        <i class="fas fa-bars" onclick="openmenu()"></i>
      </nav>
    </div>
  </div>

  <!-- search part -->
  <div class="search-container">
    <div class="custom-search-form">
      <h2>Search Form</h2>
      <form method="GET">
        <input class="custom-search-input" type="text" name="search" placeholder="Enter your search" />
        <button class="custom-search-button" type="submit">Search</button>
      </form>
    </div>
  </div>

  <!-- Display search results or all cars -->
  <?php if ($result) : ?>
    <div id="collection">
      <?php
      // Display fetched data
      while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="collection-card">';
        echo '<img src="' . $row['image_path'] . '" alt="' . $row['make'] . '" />';
        echo '<h3>' . $row['make'] . ' Collection</h3>';
        echo '</div>';
      }
      ?>
    </div>
  <?php endif; ?>

  <script>
    var side = document.getElementById("sidemenu");

    function openmenu() {
      side.style.right = "0";
    }

    function closemenu() {
      side.style.right = "-200px";
    }
  </script>
</body>

</html>