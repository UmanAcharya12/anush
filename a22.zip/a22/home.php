<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="style.css" />
  <script src="https://kit.fontawesome.com/9964e735a4.js" crossorigin="anonymous"></script>
  <title>Vehicle Home</title>
</head>

<body>

  <div class="database-content">
    <?php
    // Include the PHP file that contains the database connection
    include('database.php');

    // Fetch data from the database 
    $query = "SELECT * FROM users";
    $result = mysqli_query($conn, $query);

    // Display fetched data
    while ($row = mysqli_fetch_assoc($result)) {
      // echo '<p>User ID: ' . $row['id'] . ', Username: ' . $row['user'] . '</p>';
    }
    ?>
  </div>

  <div id="header">
    <div class="container">
      <nav>
        <img src="images/logo2.png" alt="logo" class="logo" />
        <ul id="sidemenu">
          <li><a href="home.php">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="register.php">Register</a></li>
          <li><a href="login.php">Login</a></li>
          <li><a href="search.php">Search</a></li>
          <i class="fas fa-times" onclick="closemenu()"></i>
        </ul>
        <i class="fas fa-bars" onclick="openmenu()"></i>
      </nav>
    </div>
  </div>

  <!-- heading part after nav bar -->
  <div class="headertext">
    <div class="main-text">
      <h3>Vehicle Home</h3>
      <p>
        Find your dream vehicle at Vehicle Home. Whether you're looking <br />
        for a stylish sedan, a rugged SUV, or an efficient hybrid, we've got
        <br />
        you covered. Browse our extensive inventory and get ready to drive
        <br />
        your dream car with just one click.
      </p>
    </div>
    <div class="header-image">
      <img src="images/bg2.png" alt="" />
    </div>
  </div>

  <!-- about part start form here -->
  <div class="abouttext">
    <div class="main-text">
      <h3>What We Do</h3>
      <p>
        At Car Sale Hub, our mission is to provide a seamless and enjoyable
        experience for buying and selling vehicles. Explore a vast selection
        of high-quality cars, ranging from stylish sedans to robust SUVs and
        efficient hybrids. We connect buyers with trusted sellers, making the
        car shopping process convenient and reliable. Whether you're looking
        to upgrade your ride or sell your current vehicle, Car Sale Hub is
        your go-to destination for all your automotive needs. Join us in
        redefining the way cars are bought and sold!
      </p>
    </div>

    <div class="aboutimage">
      <img src="images\bg.png" alt="" height="500px" width="500px" />
    </div>
  </div>

  <!-- our services part -->
  <h1 style="display: flex; justify-content: center; align-items: center">
    Our Services
  </h1>
  <div id="services">
    <div class="service-card">
      <h2>Vehicle Sales</h2>
    </div>

    <div class="service-card">
      <h2>Financing Options</h2>
    </div>

    <div class="service-card">
      <h2>Online Vehicle Search and Purchase</h2>
    </div>

    <div class="service-card">
      <h2>Insurance Services</h2>
    </div>

    <div class="service-card">
      <h2>Test Ride</h2>
    </div>
  </div>

  <!-- home.php -->
  <h1 style="display: flex; justify-content: center; align-items: center">
    Our Collections
  </h1>
  <div id="collection">
    <?php
    // Fetch data from the database
    $query = "SELECT * FROM cars";
    $result = mysqli_query($conn, $query);

    // Display fetched data
    while ($row = mysqli_fetch_assoc($result)) {
      echo '<div class="collection-card">';
      echo '<img src="' . $row['image_path'] . '" alt="' . $row['make'] . '" />';
      echo '<h3>' . $row['make'] . ' Collection</h3>';
      echo '</div>';
    }

    // Close the database connection
    mysqli_close($conn);
    ?>
  </div>

  <!-- social icons part -->
  <div class="social-icons">
    <i class="fa-brands fa-facebook"></i>
    <i class="fa-brands fa-instagram"></i>
    <i class="fa-brands fa-linkedin-in"></i>
  </div>

  <!-- Contact Us Section -->
  <div class="contact-part">
    <h1 style="
          display: flex;
          justify-content: center;
          align-items: center;
          margin-top: 30px;
        ">
  </div>

  <!-- footer part -->
  <footer>
    <div class="container">
      <p>&copy; 2023 Vehicle Home. All rights reserved.</p>
    </div>
  </footer>

  <script>
    var side = document.getElementById("sidemenu");

    function openmenu() {
      side.style.right = "0";
    }

    function closemenu() {
      side.style.right = "-200px";
    }
  </script>

</body>

</html>