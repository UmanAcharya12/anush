<!-- register.php -->

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="style.css" />
  <script src="https://kit.fontawesome.com/9964e735a4.js" crossorigin="anonymous"></script>
  <title>Vehicle Home</title>
  <style></style>
</head>

<body>
  <div id="header">
    <div class="container">
      <nav>
        <img src="images/logo2.png" alt="logo" class="logo" />
        <ul id="sidemenu">
          <li><a href="home.php">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="register.php">Register</a></li>
          <li><a href="login.php">Login</a></li>
          <li><a href="search.php">Search</a></li>
          <i class="fas fa-times" onclick="closemenu()"></i>
        </ul>
        <i class="fas fa-bars" onclick="openmenu()"></i>
      </nav>
    </div>
  </div>

  <?php
  // Include the PHP file that contains the database connection
  include('database.php');

  // Check if the form is submitted
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch values from the form
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert data into the database
    $insertQuery = "INSERT INTO users (name, address, phone, email, username, password) VALUES ('$name', '$address', '$phone', '$email', '$username', '$hashedPassword')";
    $insertResult = mysqli_query($conn, $insertQuery);

    if ($insertResult) {
      echo '<p>Data successfully inserted into the database!</p>';
    } else {
      echo '<p>Error inserting data into the database: ' . mysqli_error($conn) . '</p>';
    }
  }

  // Fetch data from the database 
  $query = "SELECT * FROM users";
  $result = mysqli_query($conn, $query);

  // Display fetched data
  echo '<div id="stored-data">';
  while ($row = mysqli_fetch_assoc($result)) {
    echo '<p>User ID: ' . $row['id'] . ', Name: ' . $row['name'] . ', Username: ' . $row['username'] . '</p>';
  }
  echo '</div>';

  // Close the database connection
  mysqli_close($conn);
  ?>

  <div class="form-container">
    <form id="registrationForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <h2>Car Seller Registration</h2>
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" required />

      <label for="address">Address:</label>
      <input type="text" id="address" name="address" required />

      <label for="phone">Phone number:</label>
      <input type="tel" id="phone" name="phone" required />

      <label for="email">Email address:</label>
      <input type="email" id="email" name="email" required />

      <label for="username">Username:</label>
      <input type="text" id="username" name="username" required />

      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required />

      <div class="error-message" id="error-message"></div>

      <button type="submit">Register</button>
    </form>
  </div>

  <script>
    var side = document.getElementById("sidemenu");

    function openmenu() {
      side.style.right = "0";
    }

    function closemenu() {
      side.style.right = "-200px";
    }
  </script>

  <script>
    document.addEventListener("DOMContentLoaded", function() {
      // Get all form inputs and button
      var formInputs = document.querySelectorAll("form input");
      var submitButton = document.querySelector("form button");

      // Add focus and blur event listeners to form inputs
      formInputs.forEach(function(input) {
        input.addEventListener("focus", function() {
          this.style.backgroundColor = "yellow";
        });

        input.addEventListener("blur", function() {
          this.style.backgroundColor = "white";
        });
      });

      // Add mouseover event listener to the button
      submitButton.addEventListener("mouseover", function() {
        this.style.backgroundColor = "lightblue";
      });

      // Add mouseout event listener to the button
      submitButton.addEventListener("mouseout", function() {
        this.style.backgroundColor = ""; // Reset to default background color
      });
    });
  </script>
</body>

</html>