<?php
// Include the PHP file that contains the database connection
include('database.php');

// Assuming you're using POST method for the form data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Insert data into the 'sellers' table
    $query = "INSERT INTO sellers (name, address, phone, email, username, password)
              VALUES ('$name', '$address', '$phone', '$email', '$username', '$password')";

    if (mysqli_query($conn, $query)) {
        echo "Seller information stored successfully.";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn); // Close the database connection
}
?>
<form id="registrationForm" action="insert_seller.php" method="post">
    <!-- Your form fields here -->
    <button type="submit">Register</button>
</form>


